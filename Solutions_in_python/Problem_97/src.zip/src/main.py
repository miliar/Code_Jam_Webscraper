'''
Created on Mar 18, 2012

@author: maria
'''

from codejam import * #@UnusedWildImport
from math import pow

def do_case():
    ll = read_ints(2)
    (from_num, to_num) = ll
    count = 0
    digit_count = len(str(from_num))
    rnumber = int(pow(10, digit_count - 1))
    for x in range(from_num, to_num+1):
        candidate = x
        to_add = set()
        for n in range(digit_count - 1): #@UnusedVariable
            candidate = candidate // 10 + (candidate % 10) * rnumber
            if candidate > x and candidate <= to_num:
                to_add.add(candidate)
                
        count += len(to_add)
            
    return [count]
     

def main():
    num_problems = read_int()
    
    for i in range(1, num_problems+1):
        print "Case #%d: %d" % tuple([i] + do_case())
        
    
if __name__ == '__main__':
#    set_input_file('sample.in')
    main()