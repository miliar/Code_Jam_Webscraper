# -*- coding: utf-8 -*-
# Google Code Jam 2013 - Qualification Round - Fair and Square
# http://code.google.com/codejam/contest/1460488/dashboard#s=p1
# © 2013 Aluísio Augusto Silva Gonçalves
# This Source Code Form is subject to the terms of the Mozilla Public License,
# version 2.0.  If a copy of the MPL was not distributed with this file, You
# can obtain one at http://mozilla.org/MPL/2.0/.


# Problem description {{{1
##########################

"""
   Fair and Square

"""


# Imports {{{1
##############

from __future__ import division, unicode_literals

import math

import CodeJam

if not CodeJam.Py3k:
	range = xrange


# Functions {{{1
################

def is_palindrome (n):
    n_ = n
    reverse = 0
    while n != 0:
        reverse = (reverse * 10) + (n % 10)
        n //= 10
    return n_ == reverse


# Entry point {{{1
##################

@CodeJam.ProblemSolver(__name__, lines=1)
def solve (input):
    in_ = [int(e) for e in input[0].split()]
    min = math.ceil(math.sqrt(in_[0]))
    max = math.floor(math.sqrt(in_[1]))
    count = 0

    for n in range(min, max + 1):
        if not is_palindrome(n):
            continue
        if is_palindrome(n ** 2):
            count += 1
    return str(count)
