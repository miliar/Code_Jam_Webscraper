#!/usr/bin/python

def check(n):
    x =str(n)
    return all(x[i] == x[len(x)-i-1] for i in xrange((len(x)+1)//2))

print "[",
for i in xrange(10000000):
    if check(i) and check(i*i):
        print i*i, ",", 
print "]"
