import sys
import repr

def reverseNumber(n, partial = 0):
    if n == 0:
        return partial
    return reverseNumber(n / 10, partial * 10 + n % 10)

def isPalindrome(x):
	return x == reverseNumber(x)

def palindromesBetween(x, y, longrepr):
	result = list()

	i = x
	while i < 100 and i < y:
		if (isPalindrome(i)):
			result.append(i)
		i = i + 1

	i = 1
	limitReached = False
	while not limitReached:
		reversal = longrepr.repr(i)[::-1]
		for _digit in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]:
			newNumber = long(str(i) + _digit + reversal)
			if (newNumber < y):
				result.append(newNumber)
			else:
				limitReached = True
		i = i + 1

	return result

if __name__ == "__main__":
	f = sys.stdin
	if len(sys.argv) >= 2:
		f = file("smalllookup.txt")
		lookup = list()
		for _line in f:
			lookup.append(long(_line))

		fn = sys.argv[1]
		if fn != '-':
			f = open(fn)

		t = int(f.readline())
		for _t in xrange(t):
			s = f.readline().split()
			a = int(s[0])
			b = int(s[1])

			count = 0
			for _lookup in lookup:
				if a <= _lookup and b >= _lookup:
					count = count + 1
				elif b < _lookup:
					break

			print "Case #%d: %d" % (_t + 1, count)

	else:
		# generate the lookup table
		longrepr = repr.Repr()
		longrepr.maxlong = 100

		# small lookup
		# for _palindrome in palindromesBetween(1, 10000000, longrepr):
		# 	if isPalindrome(_palindrome * _palindrome):
		# 		print longrepr.repr(_palindrome * _palindrome)

		# big lookup
		for _palindrome in palindromesBetween(1, 1e50, longrepr):
			if isPalindrome(_palindrome * _palindrome):
				print longrepr.repr(_palindrome * _palindrome)
