#!/usr/bin/python
import os, sys, math

fairSquares = []

def readFS(filename):
    for line in open(filename, 'r'):
        fairSquares.append(int(line[:-1]))

def solve(a, b):
    count = 0
    i = 0
    while fairSquares[i] < a and i < len(fairSquares):
        i += 1
    while fairSquares[i] <= b and i < len(fairSquares):
        count += 1
        i += 1
    return count

    

def main(filename):
    readFS('fairsquares')
    fileLines = open(filename, 'r').readlines()
    index = 0
    numCases = int(fileLines[index][:-1])
    index += 1
    for caseNum in range(numCases):
        (a, b) = [int(x) for x in fileLines[index][:-1].split(' ')]
        index += 1
        #print case
        answer = solve(a, b)
        #print caseStr
        print "Case #%d: %d" % (caseNum + 1, answer)

if __name__ == '__main__':
    main(sys.argv[1])
