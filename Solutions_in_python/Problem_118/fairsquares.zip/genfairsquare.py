#!/usr/bin/python
import sys, os

digits = range(1, 10)
pows = [pow(10, i) for i in range(52)]

def makeVal(vals):
    val = 0
    for i, num in enumerate(vals):
        val += num * pows[len(vals)-i-1]
    return val

# freedom is the last index to increment on the first half
def incVals(vals, freedom, length):
    i = freedom
    while vals[i] == 9 and i >= 0:
        newVal = 0 if i > 0 else 1
        vals[i] = newVal
        vals[length - 1 - i] = newVal
        i -= 1
    if i == -1:
        return False
    vals[i] += 1
    if i != length - 1 - i:
        vals[length - 1 - i] += 1
    return True

def genPalindromes():
    for length in range(1, 9):
        vals = [0 for i in range(length)]
        vals[0] = 1
        vals[length - 1] = 1
        # freedom is the last index to increment on the first half
        freedom = ((length-1) / 2)
        yield makeVal(vals)
        while incVals(vals, freedom, length):
            yield makeVal(vals)


def isPalindrome(p):
    digits = str(p)
    for i in range((len(digits)+1)/2):
        if digits[i] != digits[len(digits)-1-i]:
            return False
    return True

def main():
    for p in genPalindromes():
        p2 = p * p
        if isPalindrome(p2):
            print p2


if (__name__ == '__main__'):
    main()
