file = open('input.txt' ,'r')
lines = [line.rstrip('\n') for line in open('input.txt', 'r')]
casesNum = int(lines[0])
del lines[0]
caseCount = 1
lastNumbers = []
finalString = []
def countsheeps(num):
    lastNum = []
    numsFound = []
    iNum = int(num)
    numCount = 1
    while (len(numsFound) != 10):
        currentnum = numCount * iNum
        lastNum = currentnum
        currentsnum = str(currentnum)
        splitedCurrentNum = list(currentsnum)
        for i in splitedCurrentNum:
            if (int(i) not in numsFound):
                numsFound.append(int(i))
            else:
                continue
        numCount += 1
    lastNumbers.append(lastNum)

for case in lines:
    if(case == '0'):
        finalString.append('Case #' + str(caseCount) + ': INSOMNIA')
        lastNumbers.append(None)
        caseCount += 1
    else:
        countsheeps(case)
        finalString.append('Case #' + str(caseCount) + ': ' + str(lastNumbers[caseCount - 1]))
        caseCount += 1
f = open('output.txt', 'w')
f.write('\r\n'.join(finalString))
f.close()
