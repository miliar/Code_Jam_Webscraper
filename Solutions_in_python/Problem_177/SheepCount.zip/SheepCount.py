
fname = "./input.in"
#print "Will start reading"
with open(fname) as f:
    content = f.readlines()

no_of_tests = int(content[0])
#print "No of tests is %d" %(no_of_tests)

index = 1

for tc in range(no_of_tests):
    N = int(content[index])
    N_visited = [0]*10
    index = index + 1
    
    curr_no = 0
    
    if N == 0:
        print "Case #%d: INSOMNIA" % (tc + 1)
        continue
    while min(N_visited) == 0 :
        curr_no += N
        temp = curr_no
        while temp > 0:
            N_visited[temp % 10] = 1
            temp = int(temp/10)
        #print "N: %d, visited: %s" %(curr_no, N_visited)
    
    print "Case #%d: %d" % (tc + 1, curr_no)
    
