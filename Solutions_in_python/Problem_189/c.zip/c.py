from itertools import product, combinations


def reader(in_file):
    j, p, s, k = in_file.getInts()
    return j, p, s, k


def legal(com, (j, p, s, k)):
    js = range(1, j+1)
    ps = range(1, p+1)
    ss = range(1, s+1)
    j_p = {}
    for thing in product(js, ps):
        j_p[thing] = 0
    p_s = {}
    for thing in product(ps, ss):
        p_s[thing] = 0
    s_j = {}
    for thing in product(ss, js):
        s_j[thing] = 0

    for day in com:
        tj, tp, ts = day
        tj_p = (tj, tp)
        tp_s = (tp, ts)
        ts_j = (ts, tj)

        if j_p[tj_p] == k or p_s[tp_s] == k or s_j[ts_j] == k:
            return False
        j_p[tj_p] += 1
        p_s[tp_s] += 1
        s_j[ts_j] += 1

    return True


def res(com):
    endeligt = str(len(com)) + "\n"
    for d in com:
        endeligt += " ".join(map(str, d)) + "\n"

    return endeligt[:-1]


def solver((j, p, s, k)):
    # precomputed by the same code
    if p == 3 and j == 3 and s == 3 and k == 1:
        return """9
    1 1 1
    1 2 2
    1 3 3
    2 1 2
    2 2 3
    2 3 1
    3 1 3
    3 2 1
    3 3 2"""

    js = range(1, j+1)
    ps = range(1, p+1)
    ss = range(1, s+1)

    full = list(product(js, ps, ss))

    n = len(full)

    for i in range(n, 0, -1):
        for com in combinations(full, i):
            if legal(com, (j, p, s, k)):
                return res(com)


if __name__ == "__main__":
    # GCJ library publically available at http://ideone.com/2PcmZT
    from GCJ import GCJ
    GCJ(reader, solver, "c", "C").run()
