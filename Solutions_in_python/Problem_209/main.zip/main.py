import itertools
import math

K = 0
N = 0
pancakes = []

def area(index, number, cache):
    if index >= N:
        return 0
    if number == 0:
        return 0

    (cached, value) = cache[index][number]
    if cached:
        return value

    res = 0
    if number == K:
        (r, h) = pancakes[index]
        sr = math.pi * r**2
        sh = 2 * math.pi * r * h
        s = sr + sh
        res = max(s + area(index + 1, number - 1, cache), area(index + 1, number, cache))
        cache[index][number] = (True, res)
    else:
        (r, h) = pancakes[index]
        s = 2 * math.pi * r * h
        res = max(s + area(index + 1, number - 1, cache), area(index + 1, number, cache))
        cache[index][number] = (True, res)

    return res


if __name__ == '__main__':
    input = open("A-small-attempt0.in")
    output = open("A-small-attempt0.out", "w")

    caseNumber = int(input.readline())

    for case in range(0, caseNumber):
        N, K = [int(x) for x in input.readline().strip().split()]

        cache = []
        for i in range(N):
            cache.append([(False, 0) for j in range(K + 1)])

        pancakes = []
        for i in range(N):
            R, H = [int(x) for x in input.readline().strip().split()]
            pancakes.append((R, H))

        pancakes = sorted(pancakes, reverse=True)
        #print("pancakes = ", pancakes)

        res = area(0, K, cache)

        print("Case #{0:d}: {1}".format(case + 1, res))
        print("Case #{0:d}: {1}".format(case + 1, res), file=output)

    output.close()
