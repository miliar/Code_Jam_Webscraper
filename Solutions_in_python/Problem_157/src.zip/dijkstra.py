#! /usr/bin/env python
from __future__ import print_function, division
try:
    range = xrange
except NameError:
    pass

# import collections
# import functools
# import itertools as it
# import numpy as np # See http://www.numpy.org
# import sympy as sp # See http://sympy.org/en/index.html
# import gmpy2 # See https://code.google.com/p/gmpy/
# import networkx as nx # See http://networkx.github.io/

import os
import sys
# MY MODULES - available at https://github.com/lackofcheese/CodeJamLib/
sys.path.append(os.path.join(
    os.environ['GOOGLE_DRIVE'], 'Coding', 'GCJ', 'CodeJamLib'))
import codejam_io

PRODUCTS = {
    "1":{"1":"1", "i":"i",  "j":"j",  "k":"k" },
    "i":{"1":"i", "i":"-1", "j":"k",  "k":"-j"},
    "j":{"1":"j", "i":"-k", "j":"-1", "k":"i" },
    "k":{"1":"k", "i":"j",  "j":"-i", "k":"-1"}
}

def neg(q):
    if "-" in q:
        return q[1]
    else:
        return "-" + q

for t1 in ["1", "i", "j", "k"]:
    PRODUCTS[neg(t1)] = {}
    for t2 in ["1", "i", "j", "k"]:
        prod = PRODUCTS[t1][t2]
        nprod = neg(prod)
        PRODUCTS[t1][neg(t2)] = nprod
        PRODUCTS[neg(t1)][t2] = nprod
        PRODUCTS[neg(t1)][neg(t2)] = prod

def multiply(q1, q2):
    return PRODUCTS[q1][q2]

def inv(q):
    if q == "1":
        return "1"
    elif q == "-1":
        return "-1"
    else:
        return neg(q)

def toks_line(f_in, fun=int):
    return [fun(k) for k in f_in.readline().split()]

def process_first(f_in):
    num_cases = int(f_in.readline())
    other_data = None
    return num_cases, other_data

def process_case(f_in, f_out, case_no, other_data=None):
    L, X = toks_line(f_in)
    string = f_in.readline().strip()
    ans = solve(string, X)
    print("Case #{}: {}".format(case_no, ans), file=f_out)

def solve(string, X):
    if X % 4 == 0:
        return "NO"
    L = len(string)
    if L == 1:
        return "NO"
    if L * X < 3:
        return "NO"

    string_product = "1"
    for c in string:
        string_product = multiply(string_product, c)

    # Check that the overall product is -1
    if string_product == "1":
        return "NO"
    elif string_product == "-1":
        if X % 2 == 0:
            return "NO"
        cycle = {"1":0, "-1":1}
    else:
        if X % 2 != 0:
            return "NO"
        cycle = {"1":0, "-1": 2, string_product:1, neg(string_product):3}

    earliest = {"1":0}
    latest =   {string_product:L}

    product = "1"
    for i, c in enumerate(string):
        product = multiply(product, c)
        r_product = multiply(inv(product), string_product)
        if product not in earliest:
            earliest[product] = i + 1
        latest[r_product] = L - i - 1

    earliest_i = float("inf")
    for q, idx in earliest.items():
        rem = multiply("i", inv(q))
        if rem not in cycle:
            continue
        idx2 = L * cycle[rem] + idx
        if idx2 < earliest_i:
            earliest_i = idx2

    latest_k = float("inf")
    for q, idx in latest.items():
        rem = multiply(inv(q), "k")
        if rem not in cycle:
            continue
        idx2 = L * cycle[rem] + idx
        if idx2 < latest_k:
            latest_k = idx2

    if earliest_i + latest_k <= L * X:
        return "YES"
    return "NO"

if __name__ == '__main__':
    codejam_io.process_input(process_case, process_first, __file__)
