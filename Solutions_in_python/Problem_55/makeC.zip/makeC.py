import sys
import re


if len(sys.argv)>=2:
	f = open(sys.argv[1])
else:
	f = sys.stdin


def findNextStop(groups, start, remaining):
	next = start
	gain = 0
	first = True
	while remaining >= groups[next] and (first or next!=start):
		first = False
		gain += groups[next]
		remaining -= groups[next]
		next = (next+1)%len(groups)
	return next, gain

T = int(f.readline())
for i in range(T):
	R, k, N = [long(x.strip()) for x in f.readline().split()]
	groups = [long(x.strip()) for x in f.readline().split()]	
	nextStops = {}
	start = 0
	totalGain = 0
	startCycle = None
	cycleLength = 0
	cycleGain = 0
	while R>0:
		R-=1
		if next in nextStops:
			next, gain = nextStops[start]
		else:
			next, gain = findNextStop(groups, start, k)
			nextStops[start] = (next, gain)
		totalGain += gain
		if next in nextStops:
			if R >= cycleLength:
				if startCycle is None:
					startCycle = start
				cycleLength+=1
				cycleGain+=gain
				if next == startCycle:
					totalGain += (R/cycleLength) * cycleGain
					R = R % cycleLength	
		start = next
	print "Case #" + str(i+1) + ": " + str(totalGain)
