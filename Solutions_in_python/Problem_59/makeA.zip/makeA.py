import sys
import re


if len(sys.argv)>=2:
	f = open(sys.argv[1])
else:
	f = sys.stdin
	
T = int(f.readline())
for i in range(T):
	N, M = [int(x.strip()) for x in f.readline().split()]
	npaths = [f.readline().strip() for j in range(N)]
	mpaths = [f.readline().strip() for j in range(M)]
	created = 0
	for mpath in mpaths:
		max_n_path = None
		for npath in npaths:
			j=len(mpath)
			subpath = mpath
			while j>0:
				if npath.find(subpath)==0 and (npath==subpath or npath[len(subpath)]=="/") and (max_n_path is None or len(subpath)>len(max_n_path)):			
					max_n_path = subpath
					break
				k=mpath.rfind("/",0,j)
				subpath = mpath[0:k]	
				j=k
		if not max_n_path is None:
			mpath1 = mpath[len(max_n_path):]
		else:
			mpath1 = mpath
		allslashes = re.findall("/",mpath1)
		if len(allslashes)>0:
			created += len(allslashes)
			npaths.append(mpath)
	print "Case #" + str(i+1) + ": " + str(created)
	sys.stdout.flush()
