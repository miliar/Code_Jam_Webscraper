if __name__ == '__main__':
    input = open("input.txt")
    output = open("output.txt", "w")

    caseNumber = int(input.readline())

    for case in range(0, caseNumber):
        D, N = [int(x) for x in input.readline().strip().split()]
        print("D = {}, N = {}".format(D, N))

        times = []

        for i in range(N):
            dist, speed = [int(x) for x in input.readline().strip().split()]
            times.append((D - dist) / speed)

        T = max(times)
        S = D / T

        print("Case #{0:d}: {1:.6f}".format(case + 1, S))
        print("Case #{0:d}: {1:.6f}".format(case + 1, S), file=output)

    output.close()
