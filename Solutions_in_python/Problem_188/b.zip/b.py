def reader(in_file):
    b, m = in_file.getInts()
    return b, m


t = [0] * 60
t[1] = 1
for i in range(2, 60):
    sum_ = 0
    for j in range(1, i):
        sum_ += t[j]
    t[i] = sum_


def solver((b, m)):
    if m > t[b]:
        return "IMPOSSIBLE"
    out = "POSSIBLE\n"
    if m == t[b]:
        out += "0" + ("1" * (b-1)) + "\n"
    else:
        out += "0"
        for i in range(b-1, 0, -1):
            if m >= t[i]:
                out += "1"
                m -= t[i]
            else:
                out += "0"
        out += "\n"

    for i in xrange(1, b):
        out += "0"*(i+1)
        out += "1" * (b - i-1)
        out += "\n"

    return out[:-1]

if __name__ == "__main__":
    # GCJ library publically available at http://ideone.com/2PcmZT
    from GCJ import GCJ
    GCJ(reader, solver, "b", "B").run()
