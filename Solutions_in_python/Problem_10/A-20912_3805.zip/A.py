import cjutil

# p: max num of letters per key
# k: keys avail
# l: unique letter count


def calc(p,k,l,counts):
    if p*k < l:
        return "Impossible"
    
    # sort by freq, original indices included
    tups = sorted(zip(counts,xrange(len(counts))), reverse=True)
    
    keys = [0 for i in xrange(k)] # init keys as p slots free
    
    n = 0
    for i,(c,oi) in enumerate(tups):
        ki = i % len(keys)
        if keys[ki] < p:
            n += (keys[ki]+1) * c
            keys[ki] += 1
        else:
            return "Impossible"
    
    
    return n




def ioFunc(caseio):
    caseCnt = caseio.nextLine(int)
    for i in xrange(caseCnt):
        p,k,l = caseio.nextLine(int)
        counts = caseio.nextLine(int)
        
        assert len(counts) == l
        print p,k,l,":",counts
        caseio.outputCase(calc(p,k,l,counts))

cjutil.buildAndRun('A', ioFunc, extraFiles=())
