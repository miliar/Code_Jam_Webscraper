import os, datetime, re, traceback, time, sys, shutil
from zipfile import ZipFile

historyDir = './history'
compareEnabled = False

def performCompare(file1, file2): # user specific comparison
    import commands
    commands.getoutput('kompare -c ' +file1 +' ' +file2)



def _contentEquals(outputStr, fileName):
    fcont = open(fileName, 'r').read()
    return outputStr == fcont

def _printSideBySide(outputStr, fileName):
    flines = open(fileName).read().split('\n')
    outLines = outputStr.split('\n')
    def lfield(lines):
        sMaxw = str(max([len(s) for s in lines]) + 5)
        return '%-' + sMaxw + 's' # like '%-30s'
    fieldl,fieldr = lfield(outLines),lfield(flines)
    for l,r in zip(outLines, flines):
        d = {True: 'DIFFERS', False: ''}[l != r]
        print (fieldl +' ' +fieldr + ' %s') % (l,r,d)

def _genFunc(lines): 
    for l in lines: yield l


_output  = None
_caseNum = None

def rmre(path, patternStr, recursive=False):  # remove files matched by regex pattern 
    pattern = re.compile(patternStr)
    for fname in os.listdir(path):
        if pattern.search(fname):
            name = os.path.join(path, fname)
            try: 
                os.remove(name)
            except:
                if recursive:
                    rmre(name, '')
                    os.rmdir(name)

def outputCase(case):
    global _output,_caseNum
    if type(case) in (list,set,tuple): # line(s) separately?
        for i in range(len(case)):
            line = case[i]
            if i == 0:
                _output += "Case #%d: %s\n" % (_caseNum, str(line))
            else:
                _output += str(line)
    elif type(case) in (str,int,float):
        _output += "Case #%d: %s\n" % (_caseNum, str(case))
    _caseNum += 1

def parseLine(line, *types):
    parts = line.split()
    if len(types) == 0:
        if len(parts) == 1:
            return parts[0]
        elif len(parts) == 0:
            return None
        else:
            return parts
    else:
        # cast to given types and
        # repeat from beginning if less types
        casts = []
        for pi in xrange(len(parts)):
            ti = pi % len(types)
            casts.append(types[ti](parts[pi]))
        if len(casts) == 1:
            return casts[0]
        elif len(casts) == 0:
            return None
        else:
            return casts

assert parseLine('1 2 3',int) == [1,2,3]
assert parseLine('1 2 3',str,str,int) == ['1','2',3]
assert parseLine('1 2 3') == ['1','2','3']
assert parseLine('1 s 5.5', int,str,float) == [1, 's', 5.5]
assert parseLine('1', int) == 1
assert parseLine('test test2') == ['test', 'test2']
assert parseLine('test test2', str) == ['test', 'test2']
assert parseLine('test') == 'test'
assert parseLine('test', str) == 'test'
assert parseLine('1 2 b 3 4 a', int,int,str) == [1,2,'b',3,4,'a']


class CaseIO(object):
    def __init__(self, lines):
        self.gen = _genFunc(lines)
    def nextLine(self, *types):
        return parseLine(self.gen.next(), *types)
    def outputCase(self, case):
        outputCase(case)

def buildAndRun(probId, ioFunc, extraFiles=()): # ioFunc(caseio), probId: "A" or "B" etc 
    global _output,_caseNum
    
    summLines = []
    
    for setName in ('sample', 'small', 'large'):
        # if small, use fn's for example like 'A-small-attempt2.in'
        # or if exists, have the normal (like 'A-small.in')
        if setName == 'small':
            ioFnStart = probId + '-' + setName
            attemptNum = 0
            for fn in os.listdir(os.curdir):
                m = re.match(ioFnStart + '-attempt(\d+)\.in', fn)
                if m != None:
                    attemptNum = max(int(m.group(1)), attemptNum)
            
            ioFnBody = ioFnStart + '-attempt%d' % (attemptNum,)
        # otherwise use just files like 'A-large.in' 
        else:
            ioFnBody = probId + '-' + setName
        
        inFile  = ioFnBody + '.in' 
        outFile = ioFnBody + '.out'
        
        if not os.path.exists(inFile):
            print 'INPUT MISSING:', inFile
            continue
        
        # clear previous output
        _output = ""
        _caseNum = 1

        # execute solver
        try:
            inputLines = open(inFile).readlines()
            inputLines = [l.strip(os.linesep) for l in inputLines] # remove leading newlines
            
            startTime = time.time()
            ioFunc(CaseIO(inputLines))
            duration = time.time() -startTime
        except:
            traceback.print_exc()
            print 'ERRORS WHILE RUNNING:', inFile
            print _output
            print 'ERRORS WHILE RUNNING:', inFile
        
        # remove excess newline from end of output
        _output = _output.strip(os.linesep)
        
        # save trial output, correctness unknown
        try: os.makedirs(historyDir)
        except: pass
        tfnBody = ioFnBody + '.try_'
        ts = datetime.datetime.now().strftime('%j%H_%M%S')
        tryFile = tfnBody +ts
        tryFileHist = os.path.join(historyDir, tryFile)
        rmre(os.curdir + os.sep, '^' + tfnBody + r'\d{5}_\d{4}$')
        open(tryFile, 'w').write(_output)
        open(tryFileHist, 'w').write(_output)

        # check output validity if reference avail
        if os.path.exists(outFile):
            if _contentEquals(_output, outFile):
                summLines.append('PASSED (%.3f secs): %s --> %s' % (duration,inFile,outFile))
                os.remove(tryFile) # no need to keep dupes with the .out
                os.remove(tryFileHist)
            else:
                failMsg = 'FAILED: %s --> %s' % (inFile,outFile)
                print failMsg
                _printSideBySide(_output, outFile)
                print failMsg
                try:
                    if compareEnabled:
                        print 'Comparing...'
                        performCompare(outFile, tryFile)
                except:
                    print 'Problem running comparison, skipped.'
                return
        else:
            if setName == 'sample':
                summLines.append('SAMPLE OUTPUT MISSING! (%s)' % (outFile,))
            else:
                tryRep = 'READY FOR SUBMIT (%.3f secs): %s --> %s\n%s' % (duration,inFile,outFile,os.path.abspath(tryFile))
                summLines.append(tryRep)
    
    # build and show summary
    print '\n\n----------------------------------------------'
    for rep in summLines:
        print rep
    buildFile = _build(probId, extraFiles)
    print "current build:"
    print os.path.abspath(buildFile)

def _build(probId, extraFiles=()):
    # always include main file and cjutil
    mainFile,utilFile = os.path.basename(sys.argv[0]),'cjutil.py'
    
    ts             = datetime.datetime.now().strftime('%j%H_%M%S')
    buildFile      = probId + '-' + ts + '.zip'
    buildFileHist  = os.path.join(historyDir, buildFile)

    # rm any old build zip files
    rmre(os.curdir + os.sep, '^' + probId + '-' + r'\d{5}_\d{4}\.zip$')
    
    # write local build zip file
    z = ZipFile(buildFile, 'w')
    for file in set(extraFiles + (mainFile,utilFile)):
        z.write(file)
    z.close()

    # copy the file to history
    shutil.copy(buildFile, buildFileHist)

    return buildFile
