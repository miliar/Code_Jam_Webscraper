import itertools


def check(S,n):
	if n not in S:
		return 0

	if S.index(n) == 0:
		return 1

	return check(S,1+S.index(n))

def findsubsets(S,m):
	return set(itertools.combinations(S,m))


for n in range(2,26):
	S = range(2,n+1)
	count = 0
	for j in range(1,n):
		for i in findsubsets(S, j):
			#print i, check(i,n)
			count += check(i,n)
		
	print n, count
