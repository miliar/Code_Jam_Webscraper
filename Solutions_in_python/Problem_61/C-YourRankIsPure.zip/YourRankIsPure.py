import sys
import re
from inputHelpers import *

def fact(x):
    return 1 if (x in [0,1]) else reduce(lambda x, y: x*y, xrange(2, x+1))

def ncr(n, k):
    return fact(n) / (fact(k) * fact(n-k))

data = {}
done = 0

def D(k, n):
    if (k in data) and (n in data[k]):
        return data[k][n]
    else:
        val = D_compute(k, n)
        if not (k in data):
            data[k] = {}
        data[k][n] = val
        return val

def D_compute(k, n):
    if (k == n-1) or (k == 1):
        return 1
    if (k > n-1):
        return 0

    val = 0
    for i in range(min(k - 2, n - k - 1) + 1):
        val += ncr(n-k-1, i) * D(k-i-1, k)

    global done
    done = done + 1
    if (done % 1000 == 0):
        print "\r%08d computed" % done
    return val

def PureCount(n):
    val = 0
    for k in range(1, n):
        val = val + D(k, n)
    return val

T = intInput(1)[0]
for case in range(1, T+1):
    N = intInput(1)[0]

    print "Case #%d: %d" % (case, PureCount(N) % 100003)
