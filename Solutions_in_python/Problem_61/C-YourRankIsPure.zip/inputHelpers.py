import sys
import re

def intInput(length = -1):
    ''' Reads an input line from stdin and parses it as a list of integers.  Optionally,
    verifies the length of the input.  Returns a list of integers.  No input checking is
    done - if the input is incorrect (e.g. not integers), behavior is undefined. '''
    
    # Read lines until a non-blank line is read
    line = ""
    while re.match(r'^\s*$', line):
        line = sys.stdin.readline()

    # Parse as a list of integers
    # NOTE: This requires the line to be terminated by a space character
    # (such as a newline)
    data = map(int, re.findall("(\d+)\s+", line))

    if (length != -1) and (len(data) != length):
        raise Exception("Invalid input length")

    return data

def stringInput():
    # Read lines until a non-blank line is read
    line = ""
    while re.match(r'^\s*$', line):
        line = sys.stdin.readline()
    return line.strip()
