#!/usr/bin/env python
# -*- coding: utf-8 -*-

#(C)2013, nitrogenc; Google Code Jam template code.
from gcj_base import *
import itertools

class gcj_2014r1c_b(gcj):
	def subparse(self):
		tt = []
		d = self.data[1:]
		while len(d) > 0:
			tt.append(d[1].replace("\n", "").split(" "))
			d = d[2:]
		return tt
	def subprocess(self, item):
		k = 0
		perms = itertools.permutations(range(len(item)))
		for p in perms:
			s = ""
			for i in p:
				s+=item[i]
			l = []
			q = 1
			for c in s:
				if c not in l:
					#We process that character.
					l.append(c)
					s2 = str(s)
					s2 = s2.replace(c, "X")
					if s2.find("X"*s2.count("X")) == -1:
						q = 0
						break
			if q == 1:
				k+=1
		return self.int_to_str(k)

pb = gcj_2014r1c_b(sys.argv, fp=6, nbth=1, log=LOG_INFO_EXTENDED)
pb.solve()
#EOF