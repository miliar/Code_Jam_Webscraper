#!/usr/bin/env python
# -*- coding: utf-8 -*-

#(C)2013, nitrogenc; Google Code Jam template code.
#v 
import sys, traceback
from multiprocessing import Process, Queue

LOG_NOTHING = 0
LOG_ERROR = 0
LOG_INFO = 1
LOG_INFO_EXTENDED = 5
LOG_DEBUG = 10
LOG_DEBUG_EXTENDED = 20

q = Queue()

class gcj:
	def __init__(self, args, fp=6, nbth=1, log=LOG_INFO):
		self.fo = None
		self.data = []
		self.fp = fp
		self.nbth = nbth
		self.log = log
		if len(sys.argv) != 2:
			sys.stderr.write('[*] Use: %s <INPUT_FILE>\r\n' % (args[0]))
		else:
			fname = args[1]
			if fname[-3:] != '.in':
				sys.stderr.write('[!] %s is not a valid input file.\r\n' % (fname))
			else:
				try:
					fi = open(fname, 'rb')
					self.data = fi.readlines()
					fi.close()
				except:
					sys.stderr.write('[!] Unable to process input file (%s).\r\n' % (fname))
				else:
					out = fname.split('.')[0]+'.out'
					try:
						self.fo = open(out, 'wb')
					except:
						sys.stderr.write('[!] Unable to create .out file (%s).\r\n' % (out))
	def is_ok(self):
		if self.fo != None:
			return True
		else:
			return False
	def wlog(self, lvl, lmsg):
		if lvl <= self.log:
			sys.stdout.write(lmsg+'\r\n')
		return 
	def solve(self):
		if self.is_ok():
			try:
				self.parse()
				self.process()
			except:
				traceback.print_exc()
			finally:
				self.end()
		return
	def parse(self):
		self.wlog(LOG_INFO, '[>] Parsing input data...')
		self.data = self.subparse()
		self.wlog(LOG_INFO, '[>] Input data processed.')
		return
	def process(self):
		self.wlog(LOG_INFO, '[>] Solving problem...')
		if self.nbth == 1:
			self.wlog(LOG_INFO, '[*] Mono-process mode.')
			self.simple_process()
		else:
			self.wlog(LOG_INFO, '[*] Multi-process mode.')
			self.multi_process()
		self.wlog(LOG_INFO, '[>] Problem solved.')
		return 
	def simple_process(self):
		cur = 1
		for t in self.data:
			self.write(cur, self.subprocess(t))
			self.wlog(LOG_INFO, '[+] Processed: %d out of %s.' % (cur, len(self.data)))
			cur+=1
		return
	def multi_process(self):
		pses = [None for i in range(self.nbth)]
		tot = len(self.data)
		nxt = min(self.nbth, tot)
		for i in range(nxt):
			pses[i] = Process(target=self.multi_subprocess, args=(q, i, i, self.data[i],))
			pses[i].daemon = True
		self.wlog(LOG_INFO_EXTENDED, '[*] %d processes have been launched' % (nxt))
		for i in range(self.nbth):
			if pses[i] != None:
				pses[i].start()
		nec = 0
		results = []
		while nec < tot:
			r = q.get()
			self.wlog(LOG_INFO_EXTENDED, '[*] Process #%d has finished.' % (r[0]))
			if r[1] == nec:
				self.write(r[1]+1, r[2])
				nec+=1
				while len(results) > 0 and results[0][0] == nec:
					self.write(results[0][0]+1, results[0][1])
					nec+=1
					results = results[1:]
			else:
				results.append((r[1], r[2]))
				results = sorted(results)
			self.wlog(LOG_INFO, '[+] Processed: %d out of %s.' % (nec+len(results), len(self.data)))
			if nxt < tot:
				self.wlog(LOG_INFO_EXTENDED, '[*] Relaunching process #%d.' % (r[0]))
				pses[r[0]] = Process(target=self.multi_subprocess, args=(q, r[0], nxt, self.data[nxt],))
				pses[r[0]].daemon = True
				pses[r[0]].start()
				nxt+=1
			else:
				pses[r[0]] = None
		return 
	def multi_subprocess(self, q, thid, case, data):
		q.put((thid, case, self.subprocess(data)))
	def write(self, case, s):
		return self.fo.write('Case #%d: %s\r\n' % (case, s))
	def float_to_str(self, f):
		return (('%%.%df' % (self.fp)) % (f)).rstrip('0')
	def float_to_str0(self, f):
		return (('%%.%df' % (self.fp)) % (f))
	def int_to_str(self, i):
		return '%d' % (i)
	def end(self):
		self.fo.close()
		return
#EOF