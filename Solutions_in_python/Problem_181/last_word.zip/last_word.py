import argparse


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('input')

    arguments = parser.parse_args()
    input_file = arguments.input
    output_file = input_file[:-3] + "out"
    with open(input_file, "r") as f:
        n = f.readline()

        with open(output_file, "w") as output:

            for testcase in xrange(1, int(n) + 1):
                input = f.readline().rstrip()
                answer = []
                for letter in input:
                    if not answer:
                        answer = [letter]
                    else:
                        if letter < answer[0]:
                            answer.append(letter)
                        else:
                            answer.insert(0, letter)

                output.write(u"Case #{0}: {1}\n".format(testcase, "".join(answer)))
