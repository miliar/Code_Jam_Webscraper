def reader(in_file):
    return in_file.readline()


def solver(s):
    out = s[0]
    for c in s[1:]:
        if out + c > c + out:
            out = out + c
        else:
            out = c + out
    return out

if __name__ == "__main__":
    # GCJ library publically available at http://ideone.com/2PcmZT
    from GCJ import GCJ
    GCJ(reader, solver, "a", "A").run()
