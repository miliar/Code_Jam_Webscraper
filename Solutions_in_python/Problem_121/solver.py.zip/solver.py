import os

import unittest
import glob                    
import fractions
import math


#unittest.main()

def solve_bad(E,R,N,v):
    v=sorted(v,reverse=True)
    g=0
    e=E
    for vi in v:
        ve=e
        g+=vi*e
        e=min(R,E)
    return g

def solve(E,R,N,v):
    #v=sorted(v,reverse=True)
    v=reversed(v)
    g = [0 for i in range(E+1)]
    for vi in v:
        ng = [0 for i in range(E+1)]
        for e in range(E+1):
            ng[e] = max(vi*ei+g[min(e-ei+R,E)] for ei in range(e+1))
        g=ng
    return g[E]

def solve_all(input_file,output_file):
    print "Solve: %s %s" % (input_file,output_file)
    with open(output_file,'w') as outf:
        with open(input_file,'r') as inf:
            t = int(inf.readline())
            for ti in range(t):
                E,R,N=(int(i) for i in inf.readline().rstrip('\n').split(' '))
                v=[int(i) for i in inf.readline().rstrip('\n').split(' ')]
                ret = solve(E,R,N,v)
                outf.write('Case #%d: %d\n'% (ti+1,ret))


class SolverTest(unittest.TestCase):
    def _testDataDir(self):
        return os.path.join(os.path.dirname(__file__),'test_data')
    def testAll(self):
        for input_file in glob.glob(os.path.join(self._testDataDir(),'*.in.txt')):
            output_file = '.'.join(input_file.split('.')[:-2]+['out','gen','txt'])
            reference_file = '.'.join(input_file.split('.')[:-2]+['out','ref','txt'])
            solve_all(input_file,output_file)
            if os.path.exists(reference_file):
                output = file(output_file).readlines()
                reference = file(reference_file).readlines()
                self.assertEqual(output,reference)
            
if __name__=="__main__":
    unittest.main()