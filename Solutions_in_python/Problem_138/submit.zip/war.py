#!/usr/bin/env python
# encoding: utf-8

from library.boilerplate import *

import bisect

DELTA = 1e-9

def read():
  N = rint()
  naomi_blocks = [rfloat() for _ in xrange(N)]
  ken_blocks = [rfloat() for _ in xrange(N)]
  return sorted(naomi_blocks), sorted(ken_blocks)

def ken(naomi_choice, ken_blocks):
  i = bisect.bisect_left(ken_blocks, naomi_choice)
  return ken_blocks.pop(0 if i == len(ken_blocks) else i)

def honest_war(naomi_blocks, ken_blocks):
  ken_blocks = ken_blocks[:]
  score = 0
  for n in reversed(naomi_blocks):
    if ken(n, ken_blocks) < n:
      score += 1
  return score

def deceitful_war(naomi_blocks, ken_blocks):
  naomi_blocks = naomi_blocks[:]
  ken_blocks = ken_blocks[:]

  score = 0

  for i in xrange(len(naomi_blocks)):
    if ken_blocks[0] > naomi_blocks[-1]:
      ken_blocks.pop(-1)
      naomi_blocks.pop(0)
    else:
      ken(ken_blocks.pop(0), naomi_blocks)
      score += 1

  return score

def solve(naomi_blocks, ken_blocks):
  return (deceitful_war(naomi_blocks, ken_blocks),
          honest_war(naomi_blocks, ken_blocks))

def write(deceitful_score, war_score):
  print deceitful_score, war_score

if __name__ == '__main__':
  boilerplate_main(read, solve, write)
