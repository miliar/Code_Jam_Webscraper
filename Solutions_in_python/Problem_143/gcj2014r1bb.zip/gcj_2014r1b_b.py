#!/usr/bin/env python
# -*- coding: utf-8 -*-

#(C)2013, nitrogenc; Google Code Jam template code.
from gcj_base import *
import math

class gcj_2014r1b_b(gcj):
	def subparse(self):
		tt = []
		d = self.data[1:]
		for i in d:
			tt.append([int(k) for k in i.replace("\n", "").split(" ")])
		return tt
	def subprocess(self, item):
		a = item[0]
		b = item[1]
		k = item[2]
		c = 0
		for i in range(a):
			for j in range(b):
				if (i&j) < k:
					c+=1
		return self.int_to_str(c)

pb = gcj_2014r1b_b(sys.argv, fp=6, nbth=1, log=LOG_INFO_EXTENDED)
pb.solve()
#EOF