#! /usr/bin/env python
from __future__ import print_function, division
try:
    range = xrange
except NameError:
    pass

# import collections
# import functools
import itertools as it
# import numpy as np # See http://www.numpy.org
# import sympy as sp # See http://sympy.org/en/index.html
# import gmpy2 # See https://code.google.com/p/gmpy/
# import networkx as nx # See http://networkx.github.io/

import os
import sys
# MY MODULES - available at https://github.com/lackofcheese/CodeJamLib/
sys.path.append(os.path.join(
    os.environ['GOOGLE_DRIVE'], 'Coding', 'GCJ', 'CodeJamLib'))
import codejam_io

def toks_line(f_in, fun=int):
    return [fun(k) for k in f_in.readline().split()]

def process_first(f_in):
    num_cases = int(f_in.readline())
    other_data = None
    return num_cases, other_data

def process_case(f_in, f_out, case_no, other_data=None):
    A, B, K = toks_line(f_in)
    ans = solve(A, B, K)
    print("Case #{}: {}".format(case_no, ans), file=f_out)

def solve(A, B, K):
    if A <= K or B <= K:
        return A * B
    nb = max((v-1).bit_length() for v in (K, A, B))
    k = "{:0{nb}b}".format(K - 1, nb=nb)
    a = "{:0{nb}b}".format(A - 1, nb=nb)
    b = "{:0{nb}b}".format(B - 1, nb=nb)
    totals = []
    totals.append([0] * 8)
    totals[0][0] = 1
    for i in range(1, nb+1):
        totals.append([0] * 8)
        a1 = int(a[-i])
        b1 = int(b[-i])
        k1 = int(k[-i])
        for av, bv in it.product((0, 1), repeat=2):
            kv = av & bv
            clears = []
            for xv, x1 in ((av, a1), (bv, b1), (kv, k1)):
                clears.append(xv - x1)
            for ac2, bc2, kc2 in it.product((0, 1), repeat=3):
                old = ac2 + bc2*2 + kc2*4
                cc = []
                for clear, xc2 in zip(clears, (ac2, bc2, kc2)):
                    if clear == 0:
                        cc.append(xc2)
                    elif clear  == -1:
                        cc.append(0)
                    elif clear == +1:
                        cc.append(+1)
                ac, bc, kc = cc
                current = ac + bc*2 + kc*4
                totals[i][current] += totals[i-1][old]
    return totals[-1][0]

if __name__ == '__main__':
    codejam_io.process_input(process_case, process_first, __file__)
