from env import *

INPUT = "lottery/B-small-attempt0.in.txt"
OUTPUT = "lottery/output.txt"
CASE_SEP = ' '

def main():
    cases = parseCases(INPUT, parser, printout=True)
    results = runCases(cases, runCase, printout=True, casesep = CASE_SEP)
    writeResults(OUTPUT, results, casesep = CASE_SEP)
    
def parser(rowsIter):
    return dict(zip(['a','b','k'], [int(item) for item in rowsIter.next().split(' ')]))

def runCase(case):
    return simple(case)
    
    
def simple(case):
    count = 0
    for i in range(case['a']):
        for j in range(case['b']):
            if i&j<case['k']:
                count += 1
    return count

if __name__=="__main__":
    main()
