from env import *

INPUT = "repeater/A-large.in.txt"
OUTPUT = "repeater/output.txt"
CASE_SEP = ' '

def main():
    cases = parseCases(INPUT, parser, printout=True)
    results = runCases(cases, runCase, printout=True, casesep = CASE_SEP)
    writeResults(OUTPUT, results, casesep = CASE_SEP)
    
def parser(rowsIter):
    N = int(rowsIter.next())
    return {
        'N': N,
        'strings': [rowsIter.next() for _ in range(N)]
    }

def runCase(case):
    N = case['N']
    strList = case['strings']
    
    possible, arr = checkPossible(strList)
    
    if possible:
        mat = zeros((N, len(arr)))
        for i,s in enumerate(strList):
            mat[i] = buildArr(s)
        
        oper = 0
        for col in mat.T:
            oper += sum(abs(col - round(average(col))))
            
        return int(oper)
    else:
        return "Fegla Won"

def buildArr(s):
    res = []
    cprev = None
    for c in s:
        if cprev==None:
            cprev = c
            res.append(1)
        else:
            if c==cprev:
                res[-1] += 1
            else:
                cprev = c
                res.append(1)
    return res
    
    
def checkPossible(strList):
    possible = True

    prev = None
    for s in strList:
        if prev==None:
            prev = minimal(s)
        else:
            cur = minimal(s)
            if str(cur)!=str(prev):
                possible = False
            prev = cur
    return possible, buildArr(strList[0])

def minimal(s):
    res = []
    cprev = None
    for c in s:
        if cprev==None:
            cprev = c
            res.append(c)
        else:
            if c==cprev:
                pass
            else:
                cprev = c
                res.append(c)
    return res

if __name__=="__main__":
    main()
