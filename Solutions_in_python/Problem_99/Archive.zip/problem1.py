'''
Created on Apr 27, 2012

@author: William
'''

def parse_meta(meta):
    return int(meta)

def process(data):
    
    results = []
    for i, line in enumerate(data):
        if i % 2 == 0:
            m, l = map(int, line.split())
            cor = (l - m) + 1
            wro = cor + l + 1
        else:
            p = map(lambda i: float(i) - 0.0000000001, line.split())
            
            tp = [1 - p[0]]
            for i in range(len(p) - 1):
                tp.append(tp[-1] * p[i] / (1 - p[i]) * (1 - p[i + 1]))
            tp.append(tp[-1] * p[-1] / (1 - p[-1]))
            tp = list(reversed(tp))
            
            exps = [l + 2]
            for i in range(m + 1):
                expected = cor * sum(tp[:i + 1]) + wro * sum(tp[i + 1:])
                exps.append(expected)
                cor += 2
                wro += 2
            
            results.append('%.6f' % min(exps))
    
    return results

if __name__ == '__main__':
    print process(['3 4', '1 0.9 0.1'])

