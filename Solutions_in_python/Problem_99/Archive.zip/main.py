'''
Created on Apr 27, 2012

@author: William
'''

from time import time
import problem1 as p1
#import problem2 as p2
#import problem3 as p3

SMALL_INPUT = 'A-small-attempt0.in'
LARGE_INPUT = 'A-large.in'

def load_data(file_name):
    with open(file_name) as f:
        cnt = f.readline().strip()
        
        return cnt, map(lambda l: l.replace('\n', ''), f.readlines())
#        return cnt, [line.strip() for line in f.readlines()]

def write_results(f, results):
            for i, result in enumerate(results):
                f.write('Case #%d: %s\n' % (i + 1, result))

def output(results, small=True):
    
    if small:
        with open('small_results', 'w') as f:
            write_results(f, results)
    else:
        with open('large_results', 'w') as f:
            write_results(f, results)

def parse_meta(meta):
    return int(meta)

def main(file_name, mod):
    
    start = time()
    
    small = True if file_name.find('small') != -1 else False
    meta, data = load_data(file_name)
    
    try:
        handler = getattr(mod, 'parse_meta')
    except:
        handler = parse_meta
    n = handler(meta)
    
    handler = getattr(mod, 'process')
    results = handler(data)
    
    assert len(results) == n
    output(results, small)
    
    print time() - start

if __name__ == '__main__':
    
    main(SMALL_INPUT, p1)
#    main(LARGE_INPUT, p1)
    
#    main(SMALL_INPUT, p2)
#    main(LARGE_INPUT, p2)
    
#    main(SMALL_INPUT, p3)
#    main(LARGE_INPUT, p3)
    
    print 'Done!'
