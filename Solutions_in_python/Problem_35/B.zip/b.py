#!/usr/bin/env python

import io, string

class BApp(io.App):
    def constructArray(self,w,h,default=''):
        array = []
        for x in range(w):
            row = []
            for y in range(h):
                row.append(default)
            array.append(row)
        return array

    def loadCaseData(self,data,start):
        h,w = data[start].split(' ')
        h = int(h)
        w = int(w)
        
        map = self.constructArray(w,h)

        for y in range(h):
            line = data[start+1+y].split(' ')
            for x in range(w):
                map[x][y] = line[x]

        return start+1+h, [h,w,map]

    def calculateCase(self,case):
        h, w, map = case
        map2 = {}# self.constructArray(h,w,[])

        for y in range(h):
            for x in range(w):
                x2,y2 = self.getLowest(map,(x,y))
                #print (x,y), (x2,y2)
                #print x2, y2
                #print map2[x2][y2]
                #map2[x2][y2].append((x,y))
                try:
                    map2[(x2,y2)].append((x,y))
                except:
                    map2[(x2,y2)]=[(x,y)]

        map3 = self.constructArray(w,h)

        endPoints = []
        for y in range(h):
            for x in range(w):
                try:
                    pts = map2[(x,y)]
                    if (x,y) in pts:
                        list = [(x,y)]
                        for p in self.getPointsGoingTo((x,y),map2):
                            list.append(p)
                        endPoints.append(list)
                except:
                    pass

        chars = string.ascii_lowercase

        usedPts = []

        for y in range(h):
            for x in range(w):
                for pt in endPoints:
                    if (x,y) not in usedPts:
                        if (x,y) in pt:
                            #print pt
                            char =chars[0]
                            chars = chars[1:]
                            for p in pt:
                                x2,y2=p
                                map3[x2][y2]=char
                                usedPts.append(p)
                            break
        res = ['']
        for y in range(h):
            line = []
            for x in range(w):
                line.append(map3[x][y])
            line = ' '.join(line)
            res.append(line)
            
        return '\n'.join(res)

    def getPointsGoingTo(self,pt,map):
        res = []
        try:
            list = map[pt]
            if pt in list:
                del list[list.index(pt)]
        except:
            return []
        for i in list:
            res.append(i)
            pts = self.getPointsGoingTo(i,map)
            for p in pts:
                res.append(p)
        return res

    def getLowest(self,map,pt):
        n = None
        w = None
        e = None
        s = None
        
        x, y = pt
        
        if y>0:
            n = map[x][y-1]
        if y<len(map[0])-1:
            s = map[x][y+1]
        if x>0:
            w = map[x-1][y]
        if x<len(map)-1:
            e = map[x+1][y]

        current = map[x][y]

        res = pt

        if n!=None and n<current:
            current = n
            res = (x,y-1)
        if w!=None and w<current:
            current = w
            res = (x-1,y)
        if e!=None and e<current:
            current = e
            res = (x+1,y)
        if s!=None and s<current:
            current = s
            res = (x,y+1)

        return res



if __name__=='__main__':
    app = BApp()
    app.main()
