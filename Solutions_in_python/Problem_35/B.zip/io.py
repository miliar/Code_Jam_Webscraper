#!/usr/bin/env python
import sys

class App():
    def __init__(self):
        self.file = self.getFileFromArgs()

    def loadData(self,file):
        data = open(file,'r').read().split('\n')[:-1]
        cases = int(data[0])

        start = 1
        res = []

        for case in range(cases):
            start, r = self.loadCaseData(data,start)

            res.append(r)

        return res

    def loadCaseData(self,data,start):
        return 0, []

    def calculateCase(self,case):
        return []

    def output(self,n,res):
        return 'Case #%d: %s'%(n,str(res))

    def main(self):
        data = self.loadData(self.file)
        x = 1
        out = []

        for case in data:
            res = self.calculateCase(case)
            out.append(self.output(x,res))
            x+=1

        outFile = open(self.file.split('.')[0]+'.out','w')
        outFile.write('\n'.join(out))

    def getFileFromArgs(self):
        file = 'test.in'
        try:
            file = sys.argv[1]
        except:
            pass
        return file

if __name__=='__main__':
    app = App()
    app.main()
