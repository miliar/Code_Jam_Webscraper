import jam
import math


def parse():
    N, C, M = jam.input_array_of(int)
    tickets = [[x-1 for x in jam.input_array_of(int)] for i in range(M)]

    return solve(N, C, tickets)

def solve(N, C, tickets):
    train = [[] for _ in range(N)]
    buyers = [0 for i in range(C)]
    promote = 0

    for seat, buyer in tickets:
        train[seat] += [buyer]

    count = 0

    min_trains = 0

    for i, seat in enumerate(train):
        for buyer in seat:
            buyers[buyer] += 1

        count += len(seat)

        one = max(buyers)
        two = ((count - 1) // (i + 1)) + 1

        guess = max(one, two)
        min_trains = max(min_trains, guess)

    promote = 0
    for seat in train:
        promote += max(0, len(seat) - min_trains)


    return "{} {}".format(min_trains, promote)

jam.run(parse)

