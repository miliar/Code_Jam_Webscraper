class Problem:
    """
    not the best solution but whatever...
    """

    def __init__(self, readFromFile):
        global caseNumber
        caseNumber += 1
        self.case = caseNumber
        self.result = None
        self.parse(readFromFile)

    def __string__(self):
        return "Case #%d: %s" % (self.case, self.result)

    def readNLines(self, n, readFromFile):
        lines = []
        for i in range(n):
            lines.append(readFromFile.readline())
        return lines

    def parse(self, readFromFile):
        lines = self.readNLines(1, readFromFile)
        line = lines[0].split()
        self.x = int(line[0])
        self.y = int(line[1])

    def plusMinusSet(self, r):
        yield r
        for j in range(0, len(r)):
            for i in range(j, len(r)):
                r[i] = -r[i]
                yield r
                r[i] = -r[i]
            r[j] = -r[j]

    def puzzle(self, r, value):
        for i in self.plusMinusSet(r):
            if sum(i) == value:
                return i
        return []

    def split(self, r):
        r = list(r)
        if (abs(self.x) in r or self.x == 0) and (abs(self.y) in r or self.y == 0):
            if self.x != 0:
                r.remove(abs(self.x))
                py = self.puzzle(r, self.y)
                if len(py) > 0 or (self.y == 0 and len(r) == 0):
                    return True, ([self.x], py)
            else:
                r.remove(abs(self.y))
                px = self.puzzle(r, self.x)
                if len(px) > 0 or len(r) == 0:
                    return True, (px, [self.y])

        return False, ([], [])

    def convert(self, arr):
        l = len(arr[0]) + len(arr[1])
        result = ""
        for i in range(1, l+1):
            if i in arr[0]:
                result += 'E'
            elif -i in arr[0]:
                result += 'W'
            elif i in arr[1]:
                result += 'N'
            elif -i in arr[1]:
                result += 'S'
        return result

    def compute(self):
        sum = abs(self.x) + abs(self.y)
        pos = 1
        while (pos * (pos + 1)) / 2 < sum:
            pos += 1
        while True:
            pos += 1
            success, split = self.split(range(1, pos))
            if success:
                break
        self.result = self.convert(split)

def processFiles(inFile, outFile):
    testNumbers = eval(inFile.readline())
    tests = []
    for i in range(testNumbers):
        tests.append(Problem(inFile))
    for test in tests:
        test.compute()
        outFile.write(test.__string__() + '\n')


def process(inFileName, outFileName):
    inFile = open(inFileName, 'r')
    outFile = open(outFileName, 'w')
    processFiles(inFile, outFile)
    inFile.close()
    outFile.close()


if __name__ == '__main__':
    import sys

    caseNumber = 0
    filename = sys.argv[1]
    basename = filename[:-2]
    process(filename, basename + "out")