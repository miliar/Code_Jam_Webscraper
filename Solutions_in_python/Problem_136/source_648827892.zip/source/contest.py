#!/usr/bin/env python


def problem_a(case, f):
    # f.readline().strip()
    result = ""
    yield "Case #%s: %s" % (case, result)


def max_cookie(f_cost, f_speed, target, default_speed):
    speed = default_speed
    spent = 0
    opt = spent + target / speed
    while(True):
        new_spent = spent + f_cost / speed
        new_speed = speed + f_speed
        new_opt = new_spent + target / new_speed
        if new_opt < opt:
            speed = new_speed
            spent = new_spent
            opt = new_opt
        else:
            break
    return opt


def problem_b(case, f):
    C, F, X = [float(n) for n in f.readline().strip().split(" ")]
    result = max_cookie(C, F, X, 2)
    yield "Case #%s: %s" % (case, result)


def problem_c(case, f):
    result = ""
    yield "Case #%s: %s" % (case, result)


def problem_d(case, f):
    result = ""
    yield "Case #%s: %s" % (case, result)

problem = {
    "A": problem_a,
    "B": problem_b,
    "C": problem_c,
    "D": problem_d
}
