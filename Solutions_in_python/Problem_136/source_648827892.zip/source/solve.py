#!/usr/bin/env python

import sys

#import c351101 as contest
import contest


def read_input(inf, case_processor):
    outf = inf + ".out"
    with open(inf) as f, open(outf, "w") as g:
        count = int(f.readline().strip())
        for case in xrange(count):
            for line in case_processor(case + 1, f):
                g.write("%s\n" % line)
                print line


def main_solve():
    inf = sys.argv[1]
    problem_id = inf.split("-")[1]
    read_input(inf, contest.problem[problem_id])

if __name__ == '__main__':
    main_solve()
