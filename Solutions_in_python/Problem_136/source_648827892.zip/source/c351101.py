#!/usr/bin/env python


def problem_b(case, f):
    words = f.readline().strip().split(" ")
    words = " ".join(w.strip() for w in reversed(words))
    yield "Case #%s: %s" % (case, words)


def problem_a(case, f):
    credit = int(f.readline().strip())
    item_count = int(f.readline().strip())
    prices = [int(p) for p in f.readline().strip().split(" ")]
    for i1, p1 in enumerate(prices):
        for i2, p2 in enumerate(prices[i1 + 1:]):
            if credit == p1 + p2:
                yield "Case #%s: %s %s" % (case, i1 + 1, i1 + i2 + 2)


def problem_c(case, f):
    code = {
        "abc": "2", "def": "3",
        "ghi": "4", "jkl": "5", "mno": "6",
        "pqrs": "7", "tuv": "8", "wxyz": "9",
        " ": "0"}
    ccode = dict()
    for letters, digit in code.iteritems():
        for i, l in enumerate(letters):
            ccode[l] = digit * (i + 1)
    msg = f.readline()
    coded = []
    pl = None
    for l in msg:
        if l == "\n":
            continue
        cl = ccode[l]
        if pl is not None and pl[-1] == cl[0]:
            coded.append(" ")
        coded.extend(cl)
        pl = cl
    yield "Case #%s: %s" % (case, "".join(coded))

problem = {
    "A": problem_a,
    "B": problem_b,
    "C": problem_c
}
