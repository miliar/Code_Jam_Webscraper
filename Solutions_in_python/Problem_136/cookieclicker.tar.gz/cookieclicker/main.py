from globaljam import *

def time_until(cps, goal):
    return goal / cps

def main(ic):
    c,f,x = map(float, readline().split(' '))
    elapsed = 0.0
    cps = 2
    while time_until(cps, x) > time_until(cps, c)  + time_until(cps + f, x):
        elapsed += time_until(cps, c)
        cps += f
    return '{0:.7f}'.format(time_until(cps, x) + elapsed)

runbasic(main, debug=False)
