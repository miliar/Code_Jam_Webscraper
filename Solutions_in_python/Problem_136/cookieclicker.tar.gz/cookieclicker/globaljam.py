import sys, itertools

def flatten(l):
    return list(itertools.chain.from_iterable(l))

def output_file_name(input_name):
    return input_name.rstrip('in') + 'out'

def readint():
    return int(readline())

def readline():
    return files['input'].readline().strip('\n')

def write(s):
    files['output'].write(s)

def writeline(s):
    write(s + '\n')

def writelf(s, *args):
    writeline(s.format(*args))

files = {'input' : None,
         'output' : None}

def identity(ic, r):
    return r

def rungeneric(input_function):
    file_name = sys.argv[1]
    with open(file_name) as input_file:
        with open(output_file_name(file_name), 'w') as output_file:
            files['input'] = input_file
            files['output'] = output_file
            input_function()

def runtest(input_function, limit=-1, postproc=identity):
    runtest.limit = limit
    def f():
        limit = runtest.limit
        inputs = readint()
        print inputs
        for input_counter in range(inputs):
            postproc(input_counter, input_function(input_counter))
            if limit == 0:
                return
            limit -= 1
    rungeneric(f)

def writecase(ic, result):
    writelf('Case #{0}: {1}', ic + 1, result)

def runbasic(if_, debug=True):
    if debug:
        runtest(if_, 10, writecase)
    else:
        sys.stdout = open('/dev/null', 'w')
        runtest(if_, postproc=writecase)
