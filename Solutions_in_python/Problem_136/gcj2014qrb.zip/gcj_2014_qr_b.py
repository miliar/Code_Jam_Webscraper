#!/usr/bin/env python
# -*- coding: utf-8 -*-

#(C)2013, nitrogenc; Google Code Jam template code.
from gcj_base import *

class gcj_2014_qr_b(gcj):
	def subparse(self):
		tt = []
		n = int(self.data[0])
		d = self.data[1:]
		for i in range(n):
			ff = d[i][:-1].split(" ")
			tt.append([float(ff[0]), float(ff[1]), float(ff[2])])
		return tt
	def subprocess(self, item):
		farmp = item[0]
		xtrag = item[1]
		final = item[2]
		gain = 2
		curr = 0
		sec = 0
		while True:
			b = (final-curr)/gain
			d = 0
			e = 0
			if farmp >= curr:
				d = (farmp-curr)/gain
				curr = curr+d*gain-farmp
				gain = gain+xtrag
				e = d+(final-curr)/gain
			else:
				curr-=farmp
				gain+=xtrag
			if b < e:
				return self.float_to_str0(sec+b)
			else:
				sec+=d

pb = gcj_2014_qr_b(sys.argv, fp=7, nbth=4, log=LOG_INFO_EXTENDED)
pb.solve()
#EOF