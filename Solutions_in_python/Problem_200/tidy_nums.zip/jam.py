def run(f):
    T = int(input())

    for case in range(T):
        res = f()
        
        if res is None:
            res = "IMPOSSIBLE"

        print("Case #{}: {}".format(case+1, res))