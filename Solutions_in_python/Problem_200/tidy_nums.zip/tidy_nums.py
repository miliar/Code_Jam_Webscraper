def parse():
    return solve(input().strip())

def solve(input):
    data = [int(i) for i in list(input)]

    res = [0]

    for x in data:
        if x >= res[-1]:
            res += [x]

        else:
            break

    # print(res, input)

    if len(res) > len(input):
        return int("".join([str(i) for i in res]))

    last = res[-1] - 1
    del res[-1]


    while last > 0 and res[-1] > last:
        last = res[-1] - 1
        del res[-1]

    if last == 0:
        return int("9" * (len(input) - 1))

    res += [last]

    while len(res) <= len(input):
        res += [9]

    return int("".join([str(i) for i in res]))



# def is_tidy(x):
#     ciphers = [int(i) for i in str(x)]
#     last = 0
#     for cipher in ciphers:
#         if last > cipher:
#             return False

#         last = cipher

#     return True


# def test(x):
#     res  = solve(str(x))
#     real = max([i for i in range(x+1) if is_tidy(i)])

#     if res != real:
#         print("Input", x)
#         print("Expected", real)
#         print("Real", res)

#     else:
#         print("OK")

# while True:
#     test(int(input()))

import jam
jam.run(parse)

