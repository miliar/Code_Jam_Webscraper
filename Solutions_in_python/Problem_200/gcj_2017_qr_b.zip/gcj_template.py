#!/usr/bin/env python
# -*- coding: utf-8 -*-

#(C)2013, nitrogenc; Google Code Jam template code.
from gcj_base import *

class gcj_template(gcj):
	def subparse(self):
		tt = []
		pass
		return tt
	def subprocess(self, item):
		pass
		return 'answer'

pb = gcj_template(sys.argv, fp=6, nbth=1, log=LOG_INFO_EXTENDED)
pb.solve()
#EOF