#!/usr/bin/env python
# -*- coding: utf-8 -*-

#(C)2013, nitrogenc; Google Code Jam template code.
from gcj_base import *

class gcj_2017_qr_b(gcj):
	def subparse(self):
		return [d.replace("\r", "").replace("\n", "") for d in self.data[1:]]
	def subprocess(self, item):
		k = 0
		for i in range(len(item)):
			if i == len(item)-1:
				break
			if int(item[i]) > int(item[i+1]):
				return (item[:i-k]+str(int(item[i])-1)+"9"*(len(item)-i+k-1)).lstrip("0")
			elif item[i] == item[i+1]:
				k+=1
			else:
				k = 0
		return item

pb = gcj_2017_qr_b(sys.argv, fp=6, nbth=1)
pb.solve()
#EOF