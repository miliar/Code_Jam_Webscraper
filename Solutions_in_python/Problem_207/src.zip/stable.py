#! /usr/bin/env python
from __future__ import print_function, division
try:
    range = xrange
except NameError:
    pass

# import collections
# import functools
# import itertools as it
import numpy as np # See http://www.numpy.org
# import sympy as sp # See http://sympy.org/en/index.html
# import gmpy2 # See https://code.google.com/p/gmpy/
# import networkx as nx # See http://networkx.github.io/

import os
import sys
# MY MODULES - available at https://github.com/lackofcheese/CodeJamLib/
sys.path.append(os.path.join(
    os.environ['GOOGLE_DRIVE'], 'Coding', 'GCJ', 'CodeJamLib'))
import codejam_io

def toks_line(f_in, fun=int):
    return [fun(k) for k in f_in.readline().split()]

def process_first(f_in):
    num_cases = int(f_in.readline())
    other_data = None
    return num_cases, other_data

def process_case(f_in, f_out, case_no, other_data=None):
    N, R, O, Y, G, B, V = toks_line(f_in)
    ans = solve(N, R, O, Y, G, B, V)
    if ans is None:
        ans = "IMPOSSIBLE"
    else:
        ans = ''.join(ans)
    print("Case #{}: {}".format(case_no, ans), file=f_out)

def solve(N, R, O, Y, G, B ,V):
    if R + G == N:
        if R == G:
            return ['R', 'G'] * R
        else:
            return None
    if O + B == N:
        if O == B:
            return ['O', 'B'] * O
        else:
            return None
    if V + Y == N:
        if V == Y:
            return ['V', 'Y'] * V
        else:
            return None
    if G >= R >= 1:
        return None
    if V >= Y >= 1:
        return None
    if O >= B >= 1:
        return None
    colors = np.array(['R', 'Y', 'B'])
    compounds = np.array(['G', 'V', 'O'])
    counts = np.array([R-G, Y-V, B-O])
    num_compound = np.array([G, V, O])
    order = np.argsort(counts)[::-1]

    colors = colors[order]
    compounds = compounds[order]
    counts = counts[order]
    num_compound = num_compound[order]
    slack = (counts[1] + counts[2]) - counts[0]
    if slack < 0:
        return None

    # print(colors, compounds, counts, num_compound)

    all_units = [[], [], []]
    for i in range(3):
        unit = str(colors[i] + compounds[i]) * num_compound[i] + str(colors[i])
        all_units[i].append(unit)
        for n in range(counts[i] - 1):
            all_units[i].append(colors[i])
    # print(all_units)

    arrangement = []
    for i in range(slack):
        arrangement.append(all_units[0].pop())
        arrangement.append(all_units[1].pop())
        arrangement.append(all_units[2].pop())
    for i in range(counts[1] - slack):
        arrangement.append(all_units[0].pop())
        arrangement.append(all_units[1].pop())
    for i in range(counts[2] - slack):
        arrangement.append(all_units[0].pop())
        arrangement.append(all_units[2].pop())
    # print(arrangement)
    return arrangement

if __name__ == '__main__':
    codejam_io.process_input(process_case, process_first, __file__)
