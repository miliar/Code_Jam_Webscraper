#!C:\Python33\python
	
def splitPath (path):
	if path[-1] == "/":
		path = path[0:-1]
	
	folders = []
	while True:
		path,folder = os.path.split(path)
			
		if folder != "":
			folders.append(folder)
			
		else:
			if path != "":
				folders.append(path)
				
			break

	folders.reverse()
	return folders[1:]
	
def readInts(line):
	return tuple(int(x) for x in line.strip().split())
	
def readTypes (line, *args):
	return tuple(args[i](x) for x, i in enumerate(line.strip().split()))
	
	
