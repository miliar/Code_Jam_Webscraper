#!C:\Python33\python
import numpy
import collections
import functools
import itertools

debug = True
def setDebug (value):
	global debug
	debug = value
	
def printDebug (string):
	global debug
	if debug:
		print (string)
	
def alternateChain(*iterables):
    "roundrobin('ABC', 'D', 'EF') --> A D E B F C"
    # Recipe credited to George Sakkis
    pending = len(iterables)
    nexts = itertools.cycle(iter(it).__next__ for it in iterables)
    while pending:
        try:
            for next in nexts:
                yield next()
        except StopIteration:
            pending -= 1
            nexts = itertools.cycle(itertools.islice(nexts, pending))
			
def getInRange(iterable, start, end):
	return itertools.dropwhile(lambda x: x < start, itertools.takewhile(lambda x: x <= end, iterable))
	
def grouper(n, iterable, padvalue=None):
    "grouper(3, 'abcdefg', 'x') --> ('a','b','c'), ('d','e','f'), ('g','x','x')"
    return zip(*[itertools.chain(iterable, itertools.repeat(padvalue, n-1))]*n)
	
def getFirstChange (gen1, gen2):
	for a, b in zip(gen1, gen2):
		if a != b:
			return (a, b)
	
def getIndices (gen, indices):
	largest = max(indices)
	for i, result in enumerate(gen):
		if i > largest:
			break
			
		if i in indices:
			yield result
	
class Cached:
   def __init__(self, func):
      self.func = func
      self.cache = {}
	  
   def __call__(self, *args):
      if not isinstance(args, collections.Hashable):
         return self.func(*args)
		 
      if args in self.cache:
         return self.cache[args]
		 
      else:
         value = self.func(*args)
         self.cache[args] = value
         return value
		 
   def __repr__(self):
      return self.func.__doc__
	  
   def __get__(self, obj, objtype):
      return functools.partial(self.__call__, obj)
	  
def getLength (gen):
	result = 0
	for _ in gen:
		result += 1
	
	return result
	
def getDiagonals (array):
	diags = [array[::-1,:].diagonal(i) for i in range(-array.shape[0]+1, array.shape[1])]
	diags.extend(array.diagonal(i) for i in range(array.shape[1]-1,-array.shape[0],-1))
	
	return diags
	
def getDiagonalIndices (array):
	diags = [array[::-1,:].diag_indices(i) for i in range(-array.shape[0]+1, array.shape[1])]
	diags.extend(array.diag_indices(i) for i in range(array.shape[1]-1,-array.shape[0],-1))
	
	return diags
	
def convertWord (n, useHyphen = True):
	single = {
		"0": "zero",
		"1": "one",
		"2": "two",
		"3": "three",
		"4": "four",
		"5": "five",
		"6": "six",
		"7": "seven",
		"8": "eight",
		"9": "nine",
	}
	
	double = {
		"2": "twenty",
		"3": "thirty",
		"4": "forty",
		"5": "fifty",
		"6": "sixty",
		"7": "seventy",
		"8": "eighty",
		"9": "ninety",
	}
	
	teens = {
		"0": "ten",
		"1": "eleven",
		"2": "twelve",
		"3": "thirteen",
		"4": "fourteen",
		"5": "fifteen",
		"6": "sixteen",
		"7": "seventeen",
		"8": "eighteen",
		"9": "nineteen",
	}
	
	rest = ["thousand", "million", "billion", "trillion"]
	hyphen = "-" if useHyphen else " "
	number = str(n).lstrip("0")
	
	if number == "":
		return "zero"
	
	if len(number) == 1:
		return single[number[0]]
		
	if len(number) == 2:
		if number[0] == "1":	
			return teens[number[1]]
		
		else:
			last = single[number[1]]
			if last == "zero":
				return double[number[0]]
				
			else:
				return double[number[0]] + hyphen + last
			
	if len(number) == 3:
		sub = convertWord(number[1:], useHyphen)

		if sub == "zero":
			return single[number[0]] + " hundred"
		
		else:
			return single[number[0]] + " hundred and " + sub
				
	
	word = ""
	if number[-3:] == "0" * 3:
		hundred = ""
		
	else:
		hundred = convertWord(number[-3:], useHyphen)
		if number[-3] == "0":
			hundred = "and " + hundred
		
	number = number[:-3]
	current = 0
	parts = []
	for i in range(iDivUp(len(number), 3)):
		parts.append(convertWord(number[-3:], useHyphen) + " " + rest[current] + " ")
		number = number[:-3]
		current += 1
	
	return ("".join(reversed(parts)) + hundred).strip()		
			