#!C:\Python33\python
import sys
import fileinput

sys.path.append(r'D:\Data\Programming\Python\Libraries')
from PeterJam import *
from PeterData import *
from PeterMath import *

def main ():
	lines = fileinput.input()
	cases = int(lines.readline())
	for case in range(1, cases + 1):
		firstAnswer = int(lines.readline())
		firstRows = []
		for row in range(1, 5):
			firstRows.append(readInts(lines.readline()))
		
		secondAnswer = int(lines.readline())
		secondRows = []
		for row in range(1, 5):
			secondRows.append(readInts(lines.readline()))
		
		firstPossible = firstRows[firstAnswer - 1]
		secondPossible = secondRows[secondAnswer - 1]
		final = [x for x in firstPossible if x in secondPossible]
		answer = None
		if len(final) == 1:
			answer = final[0]
			
		if len(final) == 0:
			answer = "Volunteer cheated!"
			
		if len(final) > 1:
			answer = "Bad magician!"
		print ("Case #{0}: {1}".format(case, answer))
		
main()
