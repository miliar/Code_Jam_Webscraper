from _commons.data import init_logging
import codecs
import logging


PROJECT_NAME = 'codejam2015a'
INPUT_FILE = '../data/' + PROJECT_NAME + '/input.in'
OUTPUT_FILE = '../data/' + PROJECT_NAME + '/output.txt'

# Initiate logger
init_logging(logging.INFO)


class TestCase():
    
    number = None
    length = None
    audience = None
    
    def __init__(self, number, max_level, audience_string):
        self.number = number
        self.length = int(max_level) + 1
        self.audience = {}
        i = 0
        for level in audience_string:
            self.audience[i] = int(level)
            i += 1
        
    def get_missing_audience_for_level(self, level, added):
        needed_people = level
        previous_people = added
        for j in range(level):
            previous_people += self.audience[j]
        missing_audience = needed_people - previous_people if needed_people - previous_people > 0 else 0
        logging.debug('TestCase #%d, level %d, needed = %d, previous = %d, missing=%d', self.number, level, needed_people, previous_people, missing_audience)
        return missing_audience
    
    def get_total_missing_audience(self):
        added = 0
        logging.debug('TestCase #%d of length %d, entered', self.number, self.length)
        for i in range(1, self.length):
            missing = self.get_missing_audience_for_level(i, added)
            if missing > 0:
                added += missing
        logging.info('Case #%d: %d', self.number, added)
        return added

    def __repr__(self):
        return 'Audience %d = %s' % (self.number, self.audience)


class Main():
    
    cases = []
    
    def run(self):
        self.parse_input()
        logging.info(self.cases)
        solutions = []
        for case in self.cases:
            case_line = 'Case #%d: %d' % (case.number, case.get_total_missing_audience())
            solutions.append(case_line)
        self.write_output(solutions)
    
    def parse_input(self):
        with codecs.open(INPUT_FILE, 'r', 'utf-8') as input_file:
            i = -1
            for line in input_file:
                i += 1
                if i == 0:
                    continue
                self.cases.append(TestCase(i, line.strip().split()[0], line.strip().split()[1]))
                
    def write_output(self, lines):
        output_file = codecs.open(OUTPUT_FILE, 'w', 'utf-8')
        for line in lines:
            output_file.write(line + '\n')
        output_file.close()
    
    def __init__(self):
        logging.info('Start')
        self.run()
        logging.info('End')


Main()