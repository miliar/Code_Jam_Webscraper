import jam;
import sys;

class MyProblem(jam.Problem):

    def __init__(self, problemNo, N, L):
        self.problemNo = problemNo;
        self.N, self.L = N, L;

    def solve(self):
        #print "Solved", self.problemNo
        s = 0;
        a = 0;
        for i, c in enumerate(self.L):
            n = int(c);
            if (s < i):
                a += i - s;
                s = i;
            s += n
        return a;

class MySolver(jam.JamSeqProblems):

    def defineProblem(self, T, i, content):
        Ns, L = content.pop(0).strip().split();
        ps = MyProblem(i, int(Ns), L);
        return ps;

if __name__ == "__main__":
    fName = sys.argv[0].replace(".py", ".in") if len(sys.argv) < 2 else sys.argv[1]
    s = MySolver(fName)
    s.poolSize = 3;
    s.solve();