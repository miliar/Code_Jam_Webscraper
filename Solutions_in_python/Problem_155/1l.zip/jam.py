#!/usr/bin/env python

# Vlad's jam template

import time;
from multiprocessing import Pool

class Problem:
    """
    Generic problem representation.
    Problem can be resolved by solve() method, which returns a solution
    """
    def solve(self):
        pass;

class JamProblems(Problem):
    def __init__(self, inputFName, outputFName=None):
        self.fName = inputFName;
        self.foutName = outputFName if outputFName != None else (inputFName.replace(".in", ".out.txt"));

    def readIntLine(self, content):
        line = content.pop(0);  # get target line
        return map(int, line.split())

    def readFloatLine(self, content):
        line = content.pop(0);  # get target line
        return map(float, line.split())

    def readIntValue(self, content):
        N = int(content.pop(0))
        return N

    def readFloatValue(self, content):
        F = float(content.pop(0))
        return F

    def solve(self):
        with open(self.fName) as f: # input
            content = f.readlines();
            T = int(content.pop(0))
            print "%d cases to solve" % (T)
            self.times = [];
            with open(self.foutName, "w+") as fout:
                self.solveProblems(T, content, fout);
            #close out file
        #close input file
        totalTime = sum(self.times)
        print "Solved in %0.2f s, written to %s" % (totalTime, self.foutName)
    #

    def solveProblems(self, T, context, fout):
        for i in range(T):
            startTime = time.time();

            solution = self.solveProblem(T, i, context);
            line = "Case #%d: %s" % (i+1, solution)
            print line
            fout.write(line)
            fout.write("\n")

            timeTaken = time.time() - startTime;
            self.times.append(timeTaken);
            #end for problem


class JamSeqProblems(JamProblems):
    """
    Abstact class.
    User must implement defineProblem(Total, problemNo, context) method
    which will return an instance of Problem class.

    Problems solved sequentially.
    """

    def solveSingleProblem(self, p):
        return p.solve();

    def solveProblems(self, T,  context, fout):
        for i in range(T):
            startTime = time.time();

            p = self.defineProblem(T, i, context);
            solution = self.solveSingleProblem(p);

            line = "Case #%d: %s" % (i+1, solution)
            print line
            fout.write(line)
            fout.write("\n")

            timeTaken = time.time() - startTime;
            self.times.append(timeTaken);
            #end for problem


class JamPoolProblems(JamSeqProblems):
    """
    Abstact class.
    User must implement defineProblem(Total, problemNo, context) method
    which will return an instance of Problem class.

    Problems solved in a thread pool in parallel. Pool size can be controlled by poolSize parameter
    """

    poolSize = 4;

    def solveProblems(self, T, context, fout):
        problems = [];
        startTime = time.time();
        for i in range(T):
            p = self.defineProblem(T, i, context);
            problems.append(p);
        #end problem definition (creation)

        # do solve them
        tpool = Pool(self.poolSize);
        solutions = tpool.map(self.solveSingleProblem, problems);

        # print solutions
        for i, solution in enumerate(solutions):
            line = "Case #%d: %s" % (i+1, solution)
            print line
            fout.write(line)
            fout.write("\n")

        timeTaken = time.time() - startTime;
        self.times.append(timeTaken);
        #end for problem
