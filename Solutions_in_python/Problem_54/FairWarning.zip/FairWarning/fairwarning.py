#!/usr/bin/python
#
# Google Code Jam 2010 - Fair Warning
#
# Author: Chris Carton (ctcarton@gmail.com)
#


import sys
import os

debug=False

def gcd(sorted_list):
	def f(b,a):
		while(b != 0):
			(a, b) = (b, a%b)
		return a
	return reduce(f, sorted_list)
	
def solve_test_case(event_ages):
	event_ages.sort(reverse=True)
	event_diffs = (v - event_ages[i+1] for i,v in enumerate(event_ages[:-1]))
	m = gcd(event_diffs)
	age_of_latest = event_ages[-1]
	if (age_of_latest % m) == 0: return 0
	return (((age_of_latest / m) + 1) * m) - age_of_latest

if __name__ == '__main__':
    input = open(sys.argv[1])
    if len(sys.argv) > 2 and sys.argv[2] == "--debug": debug=True
    test_case_count = int(input.readline().strip())
    test_case = 0
    while test_case < test_case_count:
	line = input.readline().strip().split()
	events = [long(x) for x in line[1:]]
        test_case += 1
        print "Case #%d: %s" % (test_case, solve_test_case(events))
 
