import time, math, operator, re
from helper import *

t1 = starttimer()

filename = "B%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 1

mode_str = '' if is_large == 0 else '-small-attempt0' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        points = readIA(inf)
        N = points.pop(0)
        S = points.pop(0)
        p = points.pop(0)

        # possible without/with surprising
        num_valid = 0         
        num_valid_s = 0
        for i in range(N):
            if p + 2*max(p-1, 0) <= points[i]: num_valid += 1
            elif p + 2*max(p-2, 0) <= points[i]: num_valid_s += 1
        
        output = num_valid + min(num_valid_s, S)        
        outf.write("Case #%d: %d\n" % (case, output))
        print "Case #%d: %d" % (case, output)
    
finally:
    inf.close()
    outf.close()

endtimer(t1)
