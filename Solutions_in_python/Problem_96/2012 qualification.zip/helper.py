import time

def readI(f):
    return int(f.readline().rstrip())
    
def readIA(f, sep=' '):
    return map(int, f.readline().rstrip().split(sep))

def readL(f):
    return f.readline().rstrip("\n\r")

def readSA(f, sep=' '):
    return f.readline().rstrip("\n\r").split(sep)

def starttimer():
    return time.time()

def endtimer(timer):
    print "Total time: %.6f s" % (time.time() - timer)

def ncr(n, r):
    if r < 0 or r > n: return 0
    if r == 0 or r == n: return 1
    if r > n-r: return ncr(n, n-r)

    out = 1
    for i in range(r): out *= (n-i)        
    for i in range(r): out /= (i+1)
    return out

def permute(n, r):
	ways = ncr(n, r)
	
	s = range(r)
	for i in range(ways):
		yield s
		
		# go backwards through s
		for j in range(r-1, -1, -1):
			if s[j] < n-1 and (j == r-1 or s[j] < s[j+1] - 1):
				s[j] += 1
				# reset everything afterwards
				for k in range(j+1, r):
					s[k] = s[k-1] + 1
				break
				
def select(n, r):
	ways = ncr(n, r)
	
	s = range(r)
	for i in xrange(ways):
		yield s
		
		# go backwards through s
		for j in range(r-1, -1, -1):
			if s[j] < n-1 and (j == r-1 or s[j] < s[j+1] - 1):
				s[j] += 1
				# reset everything afterwards
				for k in range(j+1, r):
					s[k] = s[k-1] + 1
				break

def rref(m, eps=1e-10):
    # based on http://elonen.iki.fi/code/misc-notes/python-gaussj/
    # important, elements should all be doubles, not ints
    (rows, cols) = (len(m), len(m[0]))

    for i in range(rows):
        # find max pivot
        maxrow = i
        for j in range(i+1, rows):
            if m[j][i] > m[maxrow][i]:
                maxrow = i
            
        # swap to max pivot
        if maxrow <> i:
            m[i], m[maxrow] = m[maxrow], m[i]

        # is it singular
        if abs(m[i][i]) < eps:
            return False

        # eliminate column i
        for j in range(i+1, rows):
            c = m[j][i] / m[i][i]
            for k in range(i, cols):
                m[j][k] -= m[i][k] * c

    # backsubstitute
    for i in range(rows-1, -1, -1):
        c = m[i][i]
        for j in range(i):
            for k in range(cols-1, i-1, -1):
                m[j][k] -= m[i][k] * m[j][i] / c
        m[i][i] /= c

        # normalise row i
        for x in range(rows, cols):
            m[i][x] /= c

    return True
    
eps = 1e-7
def cmp(f1, f2):
    diff = f1 - f2
    if diff > eps: return 1
    if abs(diff) < eps: return 0
    return -1