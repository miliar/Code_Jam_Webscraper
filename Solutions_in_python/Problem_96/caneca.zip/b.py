#!/usr/bin/env python
from sys import stdin


def calculate(S, p, t):
    """
    >>> calculate(1, 5, [15, 13, 11])
    3
    >>> calculate(0, 8, [23, 22, 21])
    2
    >>> calculate(1, 1, [8, 0])
    1
    >>> calculate(2, 8, [29, 20, 8, 18, 18, 21])
    3
    >>> calculate(0, 8, [23, 22, 21] * 33)
    66
    >>> calculate(2, 8, [29, 20, 8, 18, 18, 21] * 16)
    18
    >>> calculate(5, 7, range(31) * 3)
    41

    """
    count = 0

    for num in t:
        div = num / 3
        rem = num % 3
        if div >= p:
            count += 1

        elif rem >= 1 and div + 1 >= p:
            count += 1

        elif S:
            if (rem == 2 and div + rem >= p) \
                or (rem == 0 and div != 0 and div + 1 >= p):
                S -= 1
                count += 1

    return count


def parse_input():
    T = int(stdin.readline().strip())
    
    result = []
    for idx in xrange(T):
        t = map(int, stdin.readline().strip().split(' '))
        N = t.pop(0)
        S = t.pop(0)
        p = t.pop(0)
        result.append((S, p, t))

    return result


def main():
    result = parse_input()

    idx = 1
    for test in result:
        answer = calculate(*test)
        print 'Case #{0}: {1}'.format(idx, answer)
        idx += 1


if __name__ == '__main__':
    main()
