"""
Problem

You're watching a show where Googlers (employees of Google) dance, and then each dancer is given a triplet of scores by three judges. Each triplet of scores consists of three integer scores from 0 to 10 inclusive. The judges have very similar standards, so it's surprising if a triplet of scores contains two scores that are 2 apart. No triplet of scores contains scores that are more than 2 apart.

For example: (8, 8, 8) and (7, 8, 7) are not surprising. (6, 7, 8) and (6, 8, 8) are surprising. (7, 6, 9) will never happen.

The total points for a Googler is the sum of the three scores in that Googler's triplet of scores. The best result for a Googler is the maximum of the three scores in that Googler's triplet of scores. Given the total points for each Googler, as well as the number of surprising triplets of scores, what is the maximum number of Googlers that could have had a best result of at least p?

For example, suppose there were 6 Googlers, and they had the following total points: 29, 20, 8, 18, 18, 21. You remember that there were 2 surprising triplets of scores, and you want to know how many Googlers could have gotten a best result of 8 or better.

With those total points, and knowing that two of the triplets were surprising, the triplets of scores could have been:

10 9 10
6 6 8 (*)
2 3 3
6 6 6
6 6 6
6 7 8 (*)

The cases marked with a (*) are the surprising cases. 
This gives us 3 Googlers who got at least one score of 8 or better. 
There's no series of triplets of scores that would give us a higher number than 3, 
so the answer is 3.

Input

The first line of the input gives the number of test cases, T. 
T test cases follow. Each test case consists of a single line containing 
integers separated by single spaces. 
The first integer will be 
N, the number of Googlers, 
and the second integer will be S, the number of surprising triplets of scores. 
The third integer will be p, as described above. 
Next will be N integers ti: the total points of the Googlers.
Output

For each test case, output one line containing "Case #x: y", where x is the case number (starting from 1) and y is the maximum number of Googlers who could have had a best result of greater than or equal to p.
Limits

1 <= T <= 100.
0 <= S <= N.
0 <= p <= 10.
0 <= ti <= 30.
At least S of the ti values will be between 2 and 28, inclusive.
Small dataset

1 <= N <= 3.
Large dataset

1 <= N <= 100.
Sample

Input
4
3 1 5 15 13 11
3 0 8 23 22 21
2 1 1 8 0
6 2 8 29 20 8 18 18 21

Output
Case #1: 3
Case #2: 2
Case #3: 1
Case #4: 3
"""

import util

import math
import sys

JUDGES = 3

def value_pass(value, composited_values, surprises_left, threshold, values_that_pass):
    """
    #thesis: 
        if average(value) is even then I can get value+1 using a surprise
        if average(value) is odd it's worthless to use a surprise and max will be ceil(average)  
    """
    average = value / composited_values
    if math.ceil(average) >= threshold:
        values_that_pass += 1
    else:
        is_even = (value % composited_values) == 0
        if surprises_left > 0 and average>0:
            if is_even and (average+1)>= threshold:
                values_that_pass += 1
                surprises_left -= 1
            elif not is_even and ((threshold - average) < (0.5 * composited_values)):
                values_that_pass += 1
                surprises_left -= 1
             
    return surprises_left, values_that_pass

def process(f):
    in_file = f
    lines = util.readFile(in_file, True, 1)[1:]    
    test_n = 1
    
    with open(in_file + "_out", "w") as f:
        for w in lines:
            out = ""
            #process values
            val = w.split(" ")
            N = int(val[0])
            S = int(val[1])
            points = int(val[2])
            scores = val[3:3+N]
            values_that_pass = 0
            for v in scores:
                S,values_that_pass = value_pass(float(v),JUDGES, S, points, values_that_pass)
            
            util.debug("input:%s " % w)
            out = "Case #%s: %s" % (test_n, values_that_pass)
            f.write(out + "\n")
            test_n += 1
            util.debug("out:%s " % out)

def main():
    process(sys.argv[1])
    

if __name__ == "__main__":
    main()



