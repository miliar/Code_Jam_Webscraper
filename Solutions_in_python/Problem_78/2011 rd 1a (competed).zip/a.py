import time, math, operator
from helper import *

t1 = starttimer()

filename = "A%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 1

mode_str = '' if is_large == 0 else '-small-attempt0' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

def reduce_frac(f1):
    a = f1[0]
    b = f1[1]

    if a < b: b, a = a, b
    while b <> 0:
        a, b = b, a % b
        
    return [f1[0] / a, f1[1] / a]

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        N, Pd, Pg = readIA(inf)

        possible = True

        # care about Pd mainly
        f1 = reduce_frac((Pd, 100))
        denom = f1[1]

        if N < denom: possible = False
        else:
            # can match Pg unless it is 0 or 100
            if Pg == 100 or Pg == 0:
                possible = (Pd == Pg)
                
        output = "Possible"
        if not possible: output = "Broken"
        outf.write("Case #%d: %s\n" % (case, output))
    
finally:
    inf.close()
    outf.close()

endtimer(t1)
