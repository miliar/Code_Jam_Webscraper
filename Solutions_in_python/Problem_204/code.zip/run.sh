# usage: testrun.sh

cd $1
python run.py ./$1 $2.in $2.out
