#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory.h>
#include <math.h>
#include <assert.h>
#include <stack>
#include <queue>
#include <map>
#include <set>
#include <algorithm>
#include <string>
#include <functional>
#include <vector>
#include <deque>
#include <utility>
#include <bitset>
#include <limits.h>
#include <time.h>
#include <functional>
#include <numeric>
#include <iostream>

using namespace std;
typedef long long ll;
typedef unsigned long long llu;
typedef double lf;
typedef unsigned int uint;
typedef long double llf;
typedef pair<int, int> pii;
typedef pair<ll, int> pli;

#define debug(format, ...) printf(format, __VA_ARGS__);

const int MOD = (int)1e9 + 7;

class modint {
  int v;
public:
  modint (): v(0) { }
  modint (ll v): v((v + MOD) % MOD) { }

  bool operator== (modint x) { return v == x.v; }
  bool operator!= (modint x) { return v != x.v; }

  modint operator+ (modint x) { return v + x.v; }
  modint operator- (modint x) { return v - x.v; }
  modint operator* (modint x) { return (ll)v * x.v; }

  modint& operator+= (const modint x) { return *this = (*this + x); }
  modint& operator-= (const modint x) { return *this = (*this - x); }
  modint& operator*= (const modint x) { return *this = (*this * x); }

  int operator* () { return v; }
};

const int N_ = 55, P_ = 55, MAXR = (int)1115111;
int N, P;
int R[N_], Q[N_][P_];
vector< pair<int, int> > in[MAXR + 10];
vector< pair<int, int> > out[MAXR + 10];
pair<int, int> range[N_][P_];
bool alive[N_][P_];
priority_queue< pair<int, int>, vector< pair<int, int> >, greater< pair<int, int> > > pq[N_];
int ans;

int main() {
  scanf("%d%d", &N, &P);
  for(int i = 0; i < N; i++) {
    scanf("%d", &R[i]);
  }
  for(int i = 0; i < N; i++) for(int p = 0; p < P; p++) {
    scanf("%d", &Q[i][p]);
  }

  for(int i = 0; i < N; i++) {
    int r = R[i];
    for(int p = 0; p < P; p++) {
      long double q = Q[i][p];
      // r*c*0.9 <= Q[i][p] <= r*c*1.1
      // ceil(Q[i][p] / 1.1r) <= c <= floor(Q[i][p] / 0.9r)
      int s = (int)ceil(q / 1.1 / r);
      int b = (int)floor(q / 0.9 / r);
      if(s <= b) {
        range[i][p] = make_pair(s, b);
        in[s].push_back(make_pair(i, p));
        out[b+1].push_back(make_pair(i, p));
      }
    }
  }

  for(int x = 1; x <= MAXR; x++) {
    //fprintf(stderr, "%d\n", x);
    for(auto pr : out[x]) {
      int i, p; tie(i, p) = pr;
      alive[i][p] = false;
    }
    for(auto pr : in[x]) {
      int i, p; tie(i, p) = pr;
      alive[i][p] = true;
      pq[i].push(make_pair(range[i][p].second, p));
  //    fprintf(stderr, "%d %d %d %lu\n", i, p, range[i][p].second, pq[i].size());
    }
    while(1) {
      int y = (int)1e9;
      for(int i = 0; i < N; i++) {
        int b, p = -1;
        //fprintf(stderr, "sz = %lu\n", pq[i].size());
        while(!pq[i].empty()) {
          tie(b, p) = pq[i].top();
          //printf( "%d %d %d %lu\n", i, b,p, pq[i].size());

          if(alive[i][p] && b >= x) break;
          pq[i].pop();
        }
        if(p < 0) {
          y = -1;
          break;
        }else {
          y = min(y, b);
        }
      }

      if(y >= x) {
        ans += 1;
        for(int i = 0; i < N; i++) {
          int b, p;
          assert(!pq[i].empty());
          tie(b, p) = pq[i].top();
          //fprintf(stderr, "empty? : %d\n", pq[i].empty());
          pq[i].pop();
          alive[i][p] = false;
        }
      }else {
        break;
      }
    }
  }

  printf("%d\n", ans);


  return 0;
}
