# -*- coding: utf-8 -*-

###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######

def tokenize(input_file):
    ret = []
    ret.append(input_file.readline())
    N = int(ret[0].split()[0])
    ret.append(input_file.readline())
    for i in range(N): ret.append(input_file.readline())
    return ret

###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######
###### YOU SHOULD ONLY CHANGE THIS FUNCTION ######

import multiprocessing
import subprocess, sys

if len(sys.argv) < 4:
    print("python3 run.py ./executable_name input_name output_name\n")
    exit(1)

executable_name = sys.argv[1]
input_name = sys.argv[2]
output_name = sys.argv[3]

input_file = open(input_name, "r")
output_file = open(output_name, "w")

tests = [[]]
def solve_case(t):
    sys.stderr.write("Case #%d start\n" % t)
    sys.stderr.write("".join(tests[t]))
    proc = subprocess.Popen(["time", executable_name], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    result = proc.communicate("\n".join(tests[t]))
    print("Case #%d completed\n" % t)
    return ("Case #%d: %s" % (t, result[0])).strip()

T = int(input_file.readline())
for t in range(0, T):
    tests.append(tokenize(input_file))
    if t == 77:
        print("\n".join(tests[t]))

print("%d test cases\n\n" % T)

pool = multiprocessing.Pool(3)
ans = pool.map(solve_case, range(1, T+1))
output_file.write("\n".join(ans))
