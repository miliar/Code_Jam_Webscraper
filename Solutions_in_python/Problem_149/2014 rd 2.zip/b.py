import time, math, operator, re
from helper import *

t1 = starttimer()

filename = "B%s.%s"
# 0 for test, 1 for small, 2 for large
is_large = 2

mode_str = '' if is_large == 0 else '-small-attempt1' if is_large == 1 else '-large'
infile = filename % (mode_str, 'in')
outfile = filename % (mode_str, 'out')

# parse input
inf = open(infile, 'r')
outf = open(outfile, 'w')

try:
    T = readI(inf)
    
    for case in range(1, T+1):
        N = readI(inf)
        X = readIA(inf)

        ans = 0
        for i in range(N):
            leftCount = sum(X[j] > X[i] for j in range(i))
            rightCount = sum(X[j] > X[i] for j in range(i+1, N))
            if leftCount < rightCount:
                ans += leftCount
            else:
                ans += rightCount
            
        outf.write("Case #%d: %s\n" % (case, ans))
        print "Case #%d: %s" % (case, ans)
            
finally:
    inf.close()
    outf.close()

endtimer(t1)
