import sys
import re

def getStatus(N, K):
    return 1 if (K & ((2 ** N) - 1))==((2 ** N) - 1) else 0

T = int(sys.stdin.readline())

for i in range(1, T + 1):
    line = sys.stdin.readline()
    if (len(line) < 2):
        continue
    N,K = map(int, re.findall(r'(\d+)\s+(\d+)', line)[0])
    print "Case #%d: %s" % (i, "ON" if getStatus(N,K) else "OFF")

