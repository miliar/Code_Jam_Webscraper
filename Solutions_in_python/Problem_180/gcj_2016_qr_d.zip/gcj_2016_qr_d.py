#!/usr/bin/env python
# -*- coding: utf-8 -*-

#(C)2013, nitrogenc; Google Code Jam template code.
from gcj_base import *

class gcj_2016_qr_d(gcj):
	def subparse(self):
		tt = []
		for d in self.data[1:]:
			tt.append(map(lambda x: int(x), d.replace("\r", "").replace("\n", "").split(" ")))
		return tt
	def subprocess(self, item): #item = [K, C, S].
		if item[2] == item[0]:
			return " ".join(["%d" % (i) for i in range(1, item[0]+1)])
		elif item[1] == 1 or item[2] < item[0]-1:
			return "IMPOSSIBLE"
		else:
			return " ".join(["%d" % (i) for i in range(2, item[0]+1)])

pb = gcj_2016_qr_d(sys.argv, fp=6, nbth=1, log=LOG_INFO_EXTENDED)
pb.solve()
#EOF