def reader(in_file):
    c, j = in_file.getWords()
    return c, j
from itertools import product

def solver((c, j)):
    c = list(c)
    j = list(j)

    quest = len(filter(lambda x: x == "?", c+j))

    if quest == 6:
        return "000 000"
    best = 9999
    bestc = "999"
    bestj = "999"
    for comb in product("1234567890", repeat=quest):
        comb = list(comb)
        ccan = ""
        jcan = ""
        for char in c:
            if char == "?":
                ccan += comb.pop(0)
            else:
                ccan += char
        for char in j:
            if char == "?":
                jcan += comb.pop(0)
            else:
                jcan += char
        bcan = abs(int(ccan) - int(jcan))
        if bcan < best:
            best = bcan
            bestc = ccan
            bestj = jcan
        elif bcan == best:
            if int(ccan) < int(bestc):
                bestc = ccan
                bestj = jcan
            elif int(ccan) == int(bestc):
                if int(jcan) < int(bestj):
                    bestc = ccan
                    bestj = jcan

    return bestc + " " + bestj

if __name__ == "__main__":
    # GCJ library publically available at http://ideone.com/2PcmZT
    from GCJ import GCJ
    GCJ(reader, solver, "b", "B").run()
